import 'package:mason/mason.dart';

void run(HookContext context) {
  // TODO: add pre-generation logic.
}
