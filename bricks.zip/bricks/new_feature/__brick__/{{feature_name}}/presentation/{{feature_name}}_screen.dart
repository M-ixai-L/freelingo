import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';


@RoutePage()
class {{feature_name.pascalCase()}}Screen extends StatelessWidget {
  const {{feature_name.pascalCase()}}Screen ({super.key});
  @override
  Widget build(BuildContext context) {
    return const SizedBox();
  }
}
