import 'package:injectable/injectable.dart';

@injectable
class {{feature_name.pascalCase()}}Service {
  {{feature_name.pascalCase()}}Service();
}